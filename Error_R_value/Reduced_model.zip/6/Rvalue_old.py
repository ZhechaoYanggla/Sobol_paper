#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 15 21:08:43 2023

@author: hgao
"""

import numpy as np
import math
import myokit
from scipy import integrate

from SALib.sample import saltelli
from SALib.analyze import sobol

import matplotlib.pyplot as plt
from SALib.plotting.bar import plot as barplot


def z_score_array(arr):
    """
    Compute the z-score of a 1D NumPy array.
    Parameters:
        arr (numpy.ndarray): Input 1D NumPy array.
    Returns:
        numpy.ndarray: Z-scored array.
    """
    # Calculate mean and standard deviation
    mean = np.mean(arr)
    std_dev = np.std(arr)

    # Z-score the array
    z_scored_arr = arr

    return z_scored_arr
    
    
    
    
apd30 = np.load('apd30.npy', mmap_mode='r')


apd90 = np.load('apd90.npy', mmap_mode='r')


B = np.load('B.npy', mmap_mode='r')


vmax = np.load('vmax.npy', mmap_mode='r')

vplt = np.load('vplt.npy', mmap_mode='r')

vrest = np.load('vrest.npy', mmap_mode='r')



apd30b = np.load('apd30b.npy', mmap_mode='r')


apd90b = np.load('apd90b.npy', mmap_mode='r')


Bb = np.load('Bb.npy', mmap_mode='r')


vmaxb = np.load('vmaxb.npy', mmap_mode='r')

vpltb = np.load('vpltb.npy', mmap_mode='r')

vrestb = np.load('vrestb.npy', mmap_mode='r')


apd30_flat = apd30.ravel()
apd90_flat = apd90.ravel()
B_flat = B.ravel()
vmax_flat = vmax.ravel()
vplt_flat = vplt.ravel()
vrest_flat = vrest.ravel()


apd30b_flat = apd30b.ravel()
apd90b_flat = apd90b.ravel()
Bb_flat = Bb.ravel()
vmaxb_flat = vmaxb.ravel()
vpltb_flat = vpltb.ravel()
vrestb_flat = vrestb.ravel()



#print(np.corrcoef(apd90, apd90b))


def CorCoe(a, b):
    # Find the peak voltage
    b_mean = np.mean(b)
    bres = b - b_mean
    SStot = np.sum(bres**2) 
    ares = a - b 
    SSres = np.sum(ares**2)
    R_square = 1- SSres/SStot
    
    return R_square





apd30_z = z_score_array(apd30_flat)

apd90_z = z_score_array(apd90_flat)

B_z = z_score_array(B_flat)


vmax_z = z_score_array(vmax_flat)

vplt_z = z_score_array(vplt_flat)

vrest_z = z_score_array(vrest_flat)


apd30b_z = z_score_array(apd30b_flat)

apd90b_z = z_score_array(apd90b_flat)

Bb_z = z_score_array(Bb_flat)


vmaxb_z = z_score_array(vmaxb_flat)

vpltb_z = z_score_array(vpltb_flat)

vrestb_z = z_score_array(vrestb_flat)



combined_vector = np.concatenate((apd30_z, apd90_z, B_z, vmax_z, vplt_z, vrest_z))


combined_vectorz = np.concatenate((apd30b_z, apd90b_z, Bb_z, vmaxb_z, vpltb_z, vrestb_z))

print(CorCoe(combined_vector, combined_vectorz))





















