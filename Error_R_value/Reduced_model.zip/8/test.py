#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 15 21:08:43 2023

@author: hgao
"""

import numpy as np
import math
import myokit
from scipy import integrate

from SALib.sample import saltelli
from SALib.analyze import sobol

import matplotlib.pyplot as plt
from SALib.plotting.bar import plot as barplot


apd30 = np.load('apd30.npy', mmap_mode='r')


apd90 = np.load('apd90.npy', mmap_mode='r')


B = np.load('B.npy', mmap_mode='r')


vmax = np.load('vmax.npy', mmap_mode='r')

vplt = np.load('vplt.npy', mmap_mode='r')

vrest = np.load('vrest.npy', mmap_mode='r')



apd30b = np.load('apd30b.npy', mmap_mode='r')


apd90b = np.load('apd90b.npy', mmap_mode='r')


Bb = np.load('Bb.npy', mmap_mode='r')


vmaxb = np.load('vmaxb.npy', mmap_mode='r')

vpltb = np.load('vpltb.npy', mmap_mode='r')

vrestb = np.load('vrestb.npy', mmap_mode='r')


errorapd30 = (apd30-apd30b)/apd30b
print(errorapd30.shape)
print(errorapd30[0:10])
print(np.abs(errorapd30[0:10]))
print(np.sum(np.abs(errorapd30[0:10])))


errorapd90 = (apd90-apd90b)/apd90b

errorB = (B-Bb)/Bb

errorvplt = (vplt-vpltb)/vpltb

errorvmax = (vmax-vmaxb)/vmaxb

errorvrest = (vrest-vrestb)/vrestb

Error = np.sum(np.abs(errorapd30))+np.sum(np.abs(errorapd90))+np.sum(np.abs(errorB))+np.sum(np.abs(errorvplt))+np.sum(np.abs(errorvmax))+np.sum(np.abs(errorvrest))
Error_mean = Error/12000
print(Error_mean)





















